# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

"""
test_coe_clusters
----------------------------------

Functional tests for COE clusters methods.
"""

from openstack.tests.functional import base


class TestCompute(base.BaseFunctionalTest):
    # NOTE(flwang): Currently, running Magnum on a cloud which doesn't support
    # nested virtualization will lead to timeout. So this test file is mostly
    # like a note to document why we can't have function testing for Magnum
    # clusters CRUD.
    pass
